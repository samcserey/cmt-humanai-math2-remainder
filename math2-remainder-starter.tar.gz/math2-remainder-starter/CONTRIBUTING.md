# Contributing

Contributions that follow the protocol are welcome.

## What to include

- Exact citation of the AI-assisted source being examined.
- The classical bound or estimate under discussion (quoted or precisely restated).
- The balanced equation showing both the classical error term and the generative remainder.
- A short statement that the classical result is left intact on its own terms.

## What to avoid

- Claims that a classical bound is false solely because a generative remainder exists.
- Omission of the \( R_n \) term.
- Uncited or paraphrased sources.

## Format

Markdown is preferred. Place new verifications in `examples/` with a descriptive filename. Update the README contents list if the example is substantial.

The goal is explicit accounting, not displacement of existing classical work.
