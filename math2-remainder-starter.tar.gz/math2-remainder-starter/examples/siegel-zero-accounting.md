# Example: Landau–Siegel Zero Reconstructions

## Sources

- OpenAI, Uniform exclusion of Landau–Siegel zeros (October 2026 manuscript)
- Banks, arXiv:2610.15483
- Green, Hexagon preprint 2610.00311
- Kerr, arXiv:2610.21099
- Tao, 19 October 2026 sketch

## Classical side

The reconstructions establish

\[
(1 - \beta)\log q \ge 0.003
\]

under their stated hypotheses. This bound is left intact.

## Generative side

The originating sketch was emitted by an autoregressive model. By the null,

\[
\text{Observed sketch} = P_n(\text{context}) + R_n(\text{generative}), \quad R_n \neq 0.
\]

## Balanced accounting

\[
\text{Observed sketch} = \text{Classical main term} + O(\text{classical error}) + R_n(\text{generative}).
\]

The reconstruction protocol moves the generative remainder outside the final justification. It does not cancel it. Both terms remain explicit.

## Note

This example records the distinction. It does not assert that the classical bound fails.
