# Protocol Rules

For any AI-assisted mathematical verification under this repository:

1. Cite the originating sources exactly (manuscript, arXiv, blog sketch, or equivalent).
2. Reconstruct or verify the classical estimates independently under ordinary standards of rigor.
3. Explicitly retain the generative residual term \( R_n \) arising from stochastic next-token prediction. Do not omit it.
4. Write a balanced accounting of the form  
   Observed sketch = Classical main term + O(classical error) + R_n(generative).
5. State clearly that a holding classical bound does not imply the generative remainder vanished.

These rules follow directly from the null hypothesis that finite-order autoregressive approximation leaves a non-zero Lagrange remainder.
